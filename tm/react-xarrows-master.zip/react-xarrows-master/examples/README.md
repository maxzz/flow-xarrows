easee me on:
https://codesandbox.io/s/github/Eliav2/react-xarrows/tree/master/examples?file=/src/index.tsx

if you wish to run these examples locally on your machine use "npm install" to install all dependencies and then "npm start".
reac
