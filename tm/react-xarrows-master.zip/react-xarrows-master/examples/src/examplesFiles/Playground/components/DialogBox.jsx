import React, { useState } from "react";

const DialogBox = (props) => {
  return (
    <div>
      <div>close</div>
      hey there!
    </div>
  );
};

export default DialogBox;
