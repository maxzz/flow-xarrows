import React from "react";
import ReactDOM from "react-dom";
import FewArrows from "../examples/src/examplesFiles/FewArrows";

test("renders without crashing", () => {
  const div = document.createElement("div");
  // ReactDOM.render(<FewArrows/>,div)
});
