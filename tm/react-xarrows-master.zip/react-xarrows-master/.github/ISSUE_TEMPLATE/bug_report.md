---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

[comment]: <> (replace paragraphs text where needed)
**Describe the bug & Expected behavior**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the bug:  what props where used, in what way the lib was used?  
provide preferably minimal code snippets/codesandbox/gitpod.

**Screenshots**
If applicable, add screenshots to help explain your problem.
