const exampleConf = require('./webpack.exampleConfig');
const libConf = require('./webpack.libConfig');

module.exports = [
  // exampleConf, //currently not relevant
  libConf,
];
